package com.example.demoAppICT;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;

@SpringBootApplication
@Controller
@EnableAutoConfiguration
@ComponentScan({"com.example.demoAppICT.controller","com.example.demoAppICT.service"})
public class DemoAppIctApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoAppIctApplication.class, args);
	}

}
