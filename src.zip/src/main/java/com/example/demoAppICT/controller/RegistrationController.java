package com.example.demoAppICT.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demoAppICT.model.User;
import com.example.demoAppICT.service.RegistrationService;
@RestController
public class RegistrationController {

	@Autowired
	private RegistrationService service;
	
	@PostMapping("/registeruser")
	public User registerUser(@RequestBody User user) throws Exception {
		String tempEmailId = user.getEmail();
		if(tempEmailId != null && !"".equals(tempEmailId))
		{
			User userOb = service.fetchuser(tempEmailId);
			if(userOb != null)
			{
				throw new Exception("User with "+ tempEmailId+" already exist");
			}
		}
		User userOb= null;
		userOb = service.saveuser(user);
		return userOb;
	}
	@PostMapping("/login")
	public User login(@RequestBody User user) throws Exception
	{
		String tempEmail = user.getEmail();
		String tempPassword = user.getPassword();
		User userObject = null;
		if(tempEmail !=null && tempPassword != null)
		{
			userObject = service.fetchuserAndPassword(tempEmail, tempPassword);
		}
		if(userObject == null) {
			throw new Exception("User Doesn't Exist");
		}
		return userObject;
	}
}
