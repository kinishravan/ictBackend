package com.example.demoAppICT.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demoAppICT.model.User;
import com.example.demoAppICT.repository.RegRepository;

@Service
public class RegistrationService {

	@Autowired
	private RegRepository Rep;
	public User saveuser(User user) {
		return Rep.save(user);
	}
	
	public User fetchuser(String email)
	{
		return Rep.findByEmail(email);
	}
	public User fetchuserAndPassword(String email,String password) {
		return Rep.findByEmailAndPassword(email, password);
	}
}
